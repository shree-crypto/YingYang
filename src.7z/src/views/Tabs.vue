<template>
  <ion-page>
    <ion-tabs>
      <ion-tab-bar slot="bottom">
        <ion-tab-button tab="tab1" href="/tabs/tab1">
          <ion-icon size="small"  :icon="home" />
        
        </ion-tab-button>
          
        <ion-tab-button tab="tab2" href="/tabs/tab2">
          <ion-icon size="small" :icon="notifications" />
        
        </ion-tab-button>

          <ion-tab-button tab="tab4" href="/tabs/tab4">
          <ion-icon size="small" :icon="chatboxEllipses" />
         </ion-tab-button>
        <ion-tab-button tab="tab3" href="/tabs/tab3">
          <ion-icon size="small" :icon="person" />
        </ion-tab-button>

      
         
       
      </ion-tab-bar>
    </ion-tabs>
  </ion-page>
</template>

<script lang="ts">
import { IonTabBar, IonTabButton, IonTabs, IonIcon, IonPage } from '@ionic/vue';
import {home,notifications,person, chatboxEllipses} from 'ionicons/icons';

export default {
  name: 'Tabs',
  components: {  IonTabs, IonTabBar, IonTabButton, IonIcon, IonPage },
  data() {
    return {
      chatboxEllipses,
      home,
      notifications,
      person
      
    }
  }
}
</script>