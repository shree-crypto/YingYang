<template>
  <ion-page>
    <NavBar/>
  

    <ion-content :fullscreen="false">
            <ion-infinite-scroll position="bottom">
        <ion-infinite-scroll-content
          loading-spinner="circular"
          loading-text="">
          <ion-segment class="sort" swipe-gesture="true" value="Random" @ionChange="segmentChanged($event)">
    <ion-segment-button value="Random">
      <ion-label>Random</ion-label>
    </ion-segment-button>
    <ion-segment-button value="Recent">
      <ion-label>Recent</ion-label>
    </ion-segment-button>
    <ion-segment-button value="Votes">
      <ion-label>Votes</ion-label>
    </ion-segment-button>
  </ion-segment>
        <ion-list>
         <ion-list-item></ion-list-item>
       </ion-list>
        </ion-infinite-scroll-content>
       
      </ion-infinite-scroll>
  <ion-fab class='add' vertical="bottom" fixed="true" horizontal="end">
      <ion-fab-button>
        <ion-icon :icon="addOutline"/>
      </ion-fab-button>
    </ion-fab>

    
   </ion-content>
  </ion-page>
</template>

<script lang="ts">
import {IonFab,IonFabButton, IonPage,IonContent } from '@ionic/vue';
import NavBar from '@/components/navbar.vue'
import {addOutline} from 'ionicons/icons'

export default  {
  name: 'Tab1',
  components: { IonFab,IonFabButton,NavBar, IonContent, IonPage },
  data(){
    return{addOutline}
  }
}
</script>

<style>
.add{
  position: absolute;
}

</style>